Breakout Detector EA (MQL5 Source Code)

The Breakout Detector EA is a fully automated trading bot built in MQL5 for MetaTrader 5.
It detects real breakouts, avoids fakeouts, and can even trade reversal setups when price fails to hold beyond key levels.

This system was built for traders who want a logic-based, emotion-free trading approach — using clean, customizable code.

⚙️ Main Features

✅ Detects real vs fake breakouts automatically
✅ Works on any symbol or timeframe
✅ Uses higher timeframe (HTF) levels for confirmation
✅ Analyzes candle body strength (momentum detection)
✅ Trades fakeouts in the opposite direction (optional)
✅ Automatic Take Profit and Stop Loss placement
✅ Includes visual dashboard, color-coded candles, and target lines
✅ Supports both fixed lot and risk percentage money management

💡 How It Works

The EA tracks the previous high and low from the higher timeframe (e.g. daily).

It waits for a breakout candle that is large enough compared to the average body size.

If the candle closes beyond the level, it’s marked as a real breakout.

If it fails to close beyond, it’s marked as a fakeout.

Depending on your settings, the bot trades accordingly —
• With the breakout direction for real breakouts
• Against it for fakeouts (reversal strategy)

⚙️ Inputs & Settings
Setting Group	Description
TIME FRAME SETTINGS	Selects higher timeframe or multiple of current TF
BREAKOUT SETTINGS	Adjusts body size ratio and candle detection sensitivity
CONFIRMATION SETTINGS	Confirms close beyond level and body strength
RISK SETTINGS	Sets fixed lot or dynamic risk percentage
DISPLAY SETTINGS	Controls dashboard, arrows, and labels on chart
COLOR SETTINGS	Customize all colors for bullish/bearish strength
🧩 Files Included

Breakout_Detector_EA.mq5 – main Expert Advisor code

README.txt – this file

(optional) Screenshots or templates for easy setup

🪄 Installation

Open MetaTrader 5

Click File → Open Data Folder

Go to MQL5 → Experts

Copy the .mq5 file into that folder

Restart MetaTrader 5

Attach the EA to any chart (preferably 1H or 4H)

Enable AutoTrading

🧰 Recommended Settings

HTF: Daily (D1)

Risk/Reward: 1:2

Fakeout Trading: ON

Use Money Management: Optional (2% risk)

Lot Size: 0.10 (if manual mode)

⚠️ Disclaimer

This code is for educational and development purposes only.
Backtest and forward-test before using it on a live account.
Trading involves risk — use this EA responsibly.

📩 Want Custom Bots or Help?

If you’d like to:

Modify this EA

Add new features

Or build a custom bot or app from scratch

💬 DM me directly ON INSTAGRAMME( Hash ai)
Created by: HASH AI
Language: MQL5
Platform: MetaTrader 5
Version: 1.19
Type: Expert Advisor (EA)